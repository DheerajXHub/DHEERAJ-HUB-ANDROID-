DHEERAJ HUB APP — Android V13 source project

App display name: DHEERAJ HUB APP
Planned final APK filename: DHEERAJ HUB.APK

This is the Android source project ZIP, not a compiled APK.

V13 Android changes:
- Android launcher/app label set to exactly DHEERAJ HUB APP.
- Native HUB Key screen heading updated to DHEERAJ HUB APP.
- App versionCode/versionName updated to 13 / 13.0.
- Website download button is hidden and removed inside the Android WebView only.
  The download button remains a website-only feature.
- Existing HUB Key gate, Contact Support, Instagram floating icon, WebView,
  font styling, and other existing Android features are preserved.

Important:
- The Android app continues to load the live website URL from MainActivity.java.
- Website changes appear in the app after refreshing/reopening the app.
- Do not add a download-app button to the Android app.
- Build the APK with Gradle assembleDebug. Rename the resulting APK to exactly
  DHEERAJ HUB.APK before publishing.
- This ZIP is source code only; no APK has been built yet.
