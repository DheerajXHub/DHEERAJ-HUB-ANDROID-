DHEERAJ HUB APP — ANDROID V13 SOURCE

This ZIP is the Android source project plus its GitHub Actions build workflow.
It is NOT a compiled APK.

App display name: DHEERAJ HUB APP
Version: 13.0
Final APK filename: DHEERAJ HUB.APK

Preserved Android features:
- Native HUB Key screen and existing key behavior
- Contact Support button and Instagram support link
- Floating Instagram icon after entering the app
- WebView loading the live website
- Existing app-only light font styling
- Existing file chooser and back navigation behavior

Website integration:
- The app loads the live website from MainActivity.java.
- Website tools and features are provided by that live website.
- The website's Download DHEERAJ HUB APP button and its note are removed/hidden
  inside the Android WebView only. The button is not part of the Android app.
- Firebase website configuration, when deployed on the live website, is used
  by the app's WebView too. Google sign-in may require additional WebView
  compatibility and must be tested separately.

Build:
- Upload/extract the contents at the root of the Android GitHub repository.
- GitHub Actions workflow: .github/workflows/main.yml
- Run workflow_dispatch or push a change to the listed project paths.
- Download artifact DHEERAJ-HUB-APP-V13. It contains DHEERAJ HUB.APK.

Important:
- No APK has been built yet.
- The workflow creates a debug APK, not a production-signed release APK.
- Do not activate the website download link until the updated APK has been
  built, tested, and published as a GitHub Release asset named DHEERAJ HUB.APK.
