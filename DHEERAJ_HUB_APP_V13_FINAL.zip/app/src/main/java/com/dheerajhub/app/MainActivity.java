package com.dheerajhub.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.widget.FrameLayout;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.ValueCallback;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_CHOOSER_REQUEST = 4102;
    private static final String HOME_URL = "https://dheerajxhub.github.io/DHEERAJ-HUB/";
    private static final String HUB_KEY = "DHEERAJ-HUB";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(9,10,18));
        getWindow().setNavigationBarColor(Color.rgb(9,10,18));
        // Ask for the HUB key on every fresh app launch; never persist an unlocked flag.
        showKeyScreen();
    }

    private GradientDrawable rounded(int color, int strokeColor, int strokeWidth, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        if (strokeWidth > 0) d.setStroke(strokeWidth, strokeColor);
        return d;
    }

    private GradientDrawable gradient(int start, int end, int radius) {
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{start, end});
        d.setCornerRadius(radius);
        return d;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        t.setTypeface(Typeface.create("sans-serif-light", bold ? Typeface.NORMAL : Typeface.NORMAL));
        return t;
    }

    private void showKeyScreen() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(7, 9, 20));

        LinearLayout outer = new LinearLayout(this);
        outer.setGravity(Gravity.CENTER);
        outer.setPadding(dp(20), dp(28), dp(20), dp(28));
        scroll.addView(outer, new ScrollView.LayoutParams(-1, -1));

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        card.setPadding(dp(22), dp(22), dp(22), dp(24));
        card.setBackground(rounded(Color.rgb(16, 17, 37), Color.rgb(105, 65, 180), dp(1), dp(28)));
        outer.addView(card, new LinearLayout.LayoutParams(-1, -2));

        TextView member = text("●  MEMBER AREA", 12, Color.rgb(207, 190, 255), true);
        member.setGravity(Gravity.CENTER);
        member.setPadding(dp(14), dp(8), dp(14), dp(8));
        member.setBackground(rounded(Color.rgb(37, 28, 65), Color.rgb(111, 71, 191), dp(1), dp(30)));
        LinearLayout.LayoutParams memberLp = new LinearLayout.LayoutParams(-2, -2);
        memberLp.gravity = Gravity.LEFT;
        card.addView(member, memberLp);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.ic_launcher);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams logoLp = new LinearLayout.LayoutParams(dp(76), dp(76));
        logoLp.topMargin = dp(26);
        card.addView(logo, logoLp);

        TextView heading = text("DHEERAJ HUB APP", 27, Color.WHITE, true);
        LinearLayout.LayoutParams headingLp = new LinearLayout.LayoutParams(-1, -2);
        headingLp.topMargin = dp(16);
        card.addView(heading, headingLp);

        TextView subtitle = text("Enter your HUB key to get started", 14, Color.rgb(169, 169, 193), false);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(-1, -2);
        subLp.topMargin = dp(10);
        subLp.bottomMargin = dp(28);
        card.addView(subtitle, subLp);

        TextView label = text("HUB Key", 14, Color.WHITE, true);
        label.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
        card.addView(label, new LinearLayout.LayoutParams(-1, dp(28)));

        EditText keyInput = new EditText(this);
        keyInput.setSingleLine(true);
        keyInput.setTextSize(15);
        keyInput.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        keyInput.setTextColor(Color.WHITE);
        keyInput.setHintTextColor(Color.rgb(119, 120, 143));
        keyInput.setHint("Enter your key");
        keyInput.setPadding(dp(16), 0, dp(16), 0);
        keyInput.setBackground(rounded(Color.rgb(10, 12, 27), Color.rgb(75, 72, 112), dp(1), dp(15)));
        keyInput.setImeOptions(EditorInfo.IME_ACTION_GO);
        LinearLayout.LayoutParams inputLp = new LinearLayout.LayoutParams(-1, dp(58));
        inputLp.topMargin = dp(8);
        card.addView(keyInput, inputLp);

        Button continueButton = new Button(this);
        continueButton.setText("Continue");
        continueButton.setTextColor(Color.WHITE);
        continueButton.setTextSize(16);
        continueButton.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        continueButton.setAllCaps(false);
        continueButton.setBackground(gradient(Color.rgb(143, 76, 235), Color.rgb(0, 178, 225), dp(16)));
        LinearLayout.LayoutParams continueLp = new LinearLayout.LayoutParams(-1, dp(58));
        continueLp.topMargin = dp(22);
        card.addView(continueButton, continueLp);

        Button supportButton = new Button(this);
        supportButton.setText("◎  Contact Support");
        supportButton.setTextColor(Color.WHITE);
        supportButton.setTextSize(15);
        supportButton.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        supportButton.setAllCaps(false);
        supportButton.setBackground(rounded(Color.rgb(29, 27, 54), Color.rgb(75, 72, 112), dp(1), dp(16)));
        LinearLayout.LayoutParams supportLp = new LinearLayout.LayoutParams(-1, dp(58));
        supportLp.topMargin = dp(18);
        card.addView(supportButton, supportLp);

        View.OnClickListener unlock = v -> {
            String entered = keyInput.getText().toString().trim();
            if (HUB_KEY.equals(entered)) {
                ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE))
                    .hideSoftInputFromWindow(keyInput.getWindowToken(), 0);
                showWebsite(null);
            } else {
                keyInput.setError("Invalid HUB key");
                Toast.makeText(this, "Incorrect HUB key", Toast.LENGTH_SHORT).show();
            }
        };
        continueButton.setOnClickListener(unlock);
        keyInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_GO || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                unlock.onClick(continueButton);
                return true;
            }
            return false;
        });

        supportButton.setOnClickListener(v -> openInstagram());

        setContentView(scroll);
    }

    private void openInstagram() {
        Uri instagram = Uri.parse("https://www.instagram.com/zz.dheeraj.01/");
        try {
            Intent appIntent = new Intent(Intent.ACTION_VIEW, instagram);
            appIntent.setPackage("com.instagram.android");
            startActivity(appIntent);
        } catch (Exception e) {
            startActivity(new Intent(Intent.ACTION_VIEW, instagram));
        }
    }

    // Small circular floating Instagram-style glyph, drawn locally (no image download required).
    private class InstagramIconView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rect = new RectF();
        InstagramIconView(Context context) { super(context); setLayerType(View.LAYER_TYPE_SOFTWARE, null); }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            float w = getWidth(), h = getHeight();
            paint.setShader(new android.graphics.LinearGradient(0, 0, w, h,
                new int[]{Color.rgb(143,76,235), Color.rgb(220,55,145), Color.rgb(255,145,65)},
                null, android.graphics.Shader.TileMode.CLAMP));
            c.drawCircle(w/2, h/2, Math.min(w,h)/2, paint);
            paint.setShader(null);
            paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(dp(2.4f)); paint.setColor(Color.WHITE);
            float r = w * 0.27f; rect.set(w/2-r, h/2-r, w/2+r, h/2+r);
            c.drawRoundRect(rect, dp(6), dp(6), paint);
            c.drawCircle(w/2, h/2, w*0.105f, paint);
            paint.setStyle(Paint.Style.FILL); c.drawCircle(w*0.68f, h*0.32f, dp(1.8f), paint);
        }
    }

    private int dp(float value) {
        return (int)(value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private int dp(int value) {
        return (int)(value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void showWebsite(Bundle savedInstanceState) {
        webView = new WebView(this);
        FrameLayout root = new FrameLayout(this);
        root.addView(webView, new FrameLayout.LayoutParams(-1, -1));
        InstagramIconView instagramFab = new InstagramIconView(this);
        FrameLayout.LayoutParams fabLp = new FrameLayout.LayoutParams(dp(54), dp(54), Gravity.RIGHT | Gravity.BOTTOM);
        fabLp.setMargins(0, 0, dp(18), dp(22));
        root.addView(instagramFab, fabLp);
        instagramFab.setElevation(dp(8));
        instagramFab.setOnClickListener(v -> openInstagram());
        setContentView(root);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setSupportMultipleWindows(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                // Apply the app's bundled system light typeface to the website inside this WebView only.
                // The public website viewed in Chrome is not modified by this app-only style.
                String fontCss = "(function(){var id='dheeraj-hub-app-font';var old=document.getElementById(id);if(old)old.remove();"
                    + "var s=document.createElement('style');s.id=id;s.textContent='html,body,body *{font-family:sans-serif-light,sans-serif!important;font-weight:300!important;}"
                    + "button,input,select,textarea{font-family:sans-serif-light,sans-serif!important;font-weight:400!important;}"
                    + "strong,b,h1,h2,h3,h4,h5,h6{font-weight:400!important;}';"
                    + "(document.head||document.documentElement).appendChild(s);})();";
                view.evaluateJavascript(fontCss, null);
                // App download control belongs to the public website only, never inside this Android app.
                String hideWebsiteDownload = "(function(){"
                    + "var ids=['downloadAppBtn','appDownloadNote'];"
                    + "ids.forEach(function(id){var el=document.getElementById(id);if(el)el.remove();});"
                    + "var s=document.createElement('style');s.id='dheeraj-hub-hide-app-download';"
                    + "s.textContent='#downloadAppBtn,#appDownloadNote{display:none!important;visibility:hidden!important;pointer-events:none!important;}';"
                    + "(document.head||document.documentElement).appendChild(s);"
                    + "})();";
                view.evaluateJavascript(hideWebsiteDownload, null);
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String host = uri.getHost();
                if (host != null && (host.equals("dheerajxhub.github.io") || host.equals("github.com") || host.endsWith("google.com") || host.endsWith("firebaseapp.com"))) return false;
                if ("https".equals(uri.getScheme()) || "http".equals(uri.getScheme())) {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    return true;
                }
                return true;
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent = params.createIntent();
                try { startActivityForResult(intent, FILE_CHOOSER_REQUEST); }
                catch (Exception e) { fileCallback = null; return false; }
                return true;
            }
        });
        if (savedInstanceState != null) webView.restoreState(savedInstanceState); else webView.loadUrl(HOME_URL);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && fileCallback != null) {
            Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            fileCallback.onReceiveValue(result);
            fileCallback = null;
        }
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (webView != null) webView.saveState(outState);
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (webView != null) { webView.destroy(); webView = null; }
        if (fileCallback != null) { fileCallback.onReceiveValue(null); fileCallback = null; }
        super.onDestroy();
    }
}
