DHEERAJ HUB Android wrapper project

WHAT THIS IS
- An Android Studio project that opens the existing DHEERAJ HUB website inside a full-screen WebView.
- It keeps the website hosted at https://dheerajxhub.github.io/DHEERAJ-HUB/ so updates to the website appear in the app too.
- Internet is required. The app does not copy or alter the website HTML.

BUILD APK
1. Install Android Studio on a computer.
2. Extract this ZIP and open the DHEERAJ_HUB_ANDROID_PROJECT folder in Android Studio.
3. Let Gradle sync finish.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the generated APK location.

IMPORTANT
- The app loads the live GitHub Pages URL. Make sure the website is published and working before building/testing the app.
- Firebase sign-in/admin only work after the website's Firebase configuration and Firestore rules are correctly set up.
- This is source code, not a compiled APK. A compiled APK has not been generated here because Android SDK/Gradle build tools are not installed in this environment.
